from tkinter import *
from tkinter.ttk import Progressbar
import tkinter.messagebox
import math
from gtts import gTTS
import time
import re
from py_expression_eval import Parser
import os  # This module is imported so that we can play the converted audio

# -----Creating first window--------#
window1 = Tk()
window1.title("Scientific Calculator")  # Setting the title
window1.iconbitmap(r'calculator.ico')  # Changing the window icon
window1.resizable(False, False)   # Unable the window to resize

# Determing the geometry of the window with width(413),
# height(478) and the window will start from the point(430, 100)
window1.geometry("413x478+430+100")

# --------------------------Creating the first frame in window1-----------------------#
window1_Frame = Frame(window1, bd=5, width=350, height=450, relief=RIDGE, bg="#8c8c8c")
window1_Frame.grid(row=0, column=5, columnspan=6, rowspan=2)

# ---------------------------Creating another frame in window1_Frame-------------------------#
Picture_Frame = Frame(window1_Frame, bd=5, width=400, height=400, relief=RIDGE, bg="#8c8c8c")
Picture_Frame.grid(row=0, column=5, columnspan=6, rowspan=2)

# --------------Inserting a png image in Picture_Frame-------------#
filename = PhotoImage(file=r'calculator.png')
background_label = Label(Picture_Frame, image=filename, bg='#d9d9d9')  # The Label widget is used to display the image.
background_label.place(x=0,y=0, relwidth=1, relheight=1)

# ________________________Creating another Frame below Picture_Frame-----------------------#
BottomFrame = Frame(window1_Frame, bd=5, width=350, height=300, relief=RIDGE, bg="#8c8c8c")
BottomFrame.grid(row=8, column=8)

# -------------------------Inserting a progessbar in BottomFrame----------------------#
progressBar=Progressbar(BottomFrame,orient=HORIZONTAL, length=393, mode='determinate')
progressBar.grid(row=1, column=0)

# ----------Defining a function that will act as a command for the LoadButton----------#
# ----------The LoadButton is defined after the bar function---------------------------#
def bar():
    progressBar['value'] = 20   # Setting the progressbar value
    BottomFrame.update_idletasks()   # Without processing any other activities,
                                     # the update_idletasks method calls all pending idle tasks.
    time.sleep(1)  # time.sleep(1) will pause the program for one second
    progressBar['value'] = 50
    BottomFrame.update_idletasks()
    time.sleep(1)
    progressBar['value'] = 80
    BottomFrame.update_idletasks()
    time.sleep(1)
    progressBar['value'] = 100

    # -----------------if the progressbar value reaches 100, then the calculator will appear-------------------#
    if progressBar['value'] == 100:


        window1.destroy() # We first destroy window1

        # -------------------Adding a welcome text which will be converted into an audio file----------------#
        # The text that you want to convert to audio
        mytext = 'Welcome to our Scientific Calculator! We hope that you have an enjoyable experience '

        # Language in which you want to convert
        language = 'en'

        # Text and language are passed to the engine,
        # We've set slow=False in this case.
        # This instructs the module to transform the audio at a high speed.
        myobj = gTTS(text=mytext, lang=language, slow=False)

        # Save the converted audio as a welcome.mp3 file.
        myobj.save("welcome.mp3")

        # Playing the converted file
        os.system("start welcome.mp3")
        # --------------------------------------------------------------------------------------------------------#


        parser = Parser()  # Parser() creates executable code from a python expression

        window = Tk()  # Creating a new window in which the calculator will be stored
        window.title("Scientific Calculator")  # Window title
        window.configure(background='#d9d9d9')  # setting the background color
        window.iconbitmap(r'calculator.ico')  # changing the window icon
        window.resizable(False, False)  # Unable to resize the window
        window.geometry("873x515+0+0")   # Determing the geometry of the window

        # -------------Creating the first window that covers the whole geometry of the window--------------#
        calculator = Frame(window, bd=8, width=700, height=300, padx=10, pady=10, bg="#d9d9d9", relief=RIDGE)
        calculator.grid()

        # --------------------Creating a frame in the left side of the calculator frame----------------------#
        Leftframe = Frame(calculator, bd=5, width=350, height=598, padx=10, pady=13, bg="#8c8c8c", relief=RIDGE)
        Leftframe.grid(row=0, column=0, columnspan=4, rowspan=5, pady=1)

        # --------------------Creating a frame in the right side of the calculator frame----------------------#
        Rightframe = Frame(calculator, bd=5, width=350, height=300, relief=RIDGE, bg="#8c8c8c")
        Rightframe.grid(row=0, column=5, columnspan=6, rowspan=2)

        # --------------------Creating another frame at the top of the Leftframe frame----------------------#
        Leftframe0 = Frame(Leftframe, bd=3, width=350, height=28, padx=5, bg="#8c8c8c", relief=RIDGE)
        Leftframe0.grid(row=0, column=0, columnspan=4, rowspan=1)

        # ------------Creating another frame below the Leftframe0 but still in Leftframe frame------------#
        Leftframe1 = Frame(Leftframe, bd=3, width=350, height=540, padx=5, pady=5, relief=RIDGE)
        Leftframe1.grid(row=1, column=0, columnspan=4, rowspan=15)

        # ------------Creating another frame in the right side of the Rightframe frame----------------#
        Rightframe0 = Frame(Rightframe, bd=3, width=360, height=448, padx=5, bg="#8c8c8c", relief=RIDGE)
        Rightframe0.grid(row=0, column=0, columnspan=4, rowspan=4)

        # -------------inserting a png image in Rightframe0-------------#
        filename = PhotoImage(file=r'calculator.png')
        background_label = Label(Rightframe0, image=filename, bg='#d9d9d9')  # The Label widget is used to display the image.
        background_label.place(x=0, y=0, relwidth=1, relheight=1)  # starting the image from x-axis 0 and y-axis 0 in the Rightframe0

        # The Calculator() class is a blueprint for creating objects of the calculator
        class Calculator():
            def __init__(self):  # initializing the attributes of the Calculator() class
                self.result = 0  # result value is initialised to zero
                self.current = ""  # initial value is non
                self.ValueInput = True
                self.output = False

            # Append user input to entry text
            def input(self, n):
                currentText = Text.get()

                # Check for closing brackets to append to string, eg: if last bracket is an opening bracket '(', then
                # use a closing bracket ')' and vice versa
                if n == '()':
                    n = '('
                    for c in reversed(currentText):
                        if (c == '('):
                            n = ')'
                            break
                        if (c == ')'):
                            n = '('
                            break

                # Check for PI or 2PI, if last character is number then PI should multiply
                if 'PI' in n:
                    if currentText[-1].isdigit():
                        n = '*' + n

                # if text is at initial state '0', then remove everything to allow new inputs
                if (currentText == '0'):
                    Text.delete(0, END)

                # append text to entry
                Text.insert(END, n)

            # ---------Defining the equal function-----------#
            def equal(self):
                try:
                    currentText = Text.get()

                    processedText = ''

                    for c in currentText:
                        processedText = processedText + c

                        # Specific case treat factorial
                        # Get if there is '!' then replace the text with processed value
                        # e.g: if there is '3!', will be replaced with '6'
                        if (c == '!'):
                            lastNum = re.findall(r'\d+', processedText)[-1]
                            processedText = processedText.replace(lastNum + '!', str(int(math.factorial(int(lastNum)))))

                    print("processedText", processedText)  # printing out the processedText variable

                    # Parse string math expression into compiled value
                    value = parser.parse(processedText).evaluate({})
                    Text.delete(0, END)
                    Text.insert(0, value)

                # ------if there is ZeroDivisionError, then the Text will show a "math error!" text--------#
                except ZeroDivisionError:
                    Text.delete(0, END)
                    Text.insert(0, 'math error!')

                # ------if there is SyntaxError, then the Text will show a "syntax error!" text--------#
                except SyntaxError:
                    Text.delete(0, END)
                    Text.insert(0, 'syntax error!')

                # ------if there is ValueError, then the Text will show a "math error!" text--------#
                except ValueError:
                    Text.delete(0, END)
                    Text.insert(0, 'math error!')

                # ------if there is an Exception such as e, then the Text will show a "math error!" text--------#
                except Exception as e:
                    Text.delete(0, END)
                    Text.insert(0, 'math error!')

            # ---Creating a function for the value display of Text----#
            def display(self, value):
                Text.delete(0, END)
                Text.insert(0, value)

            # -----Creating a function to deal with backspacing of values---#
            def backspace(self):
                self.current = Text.get()
                length = len(self.current) - 1  # Reducing the Text length by one
                Text.delete(length, END)

            # ---------Creating a function to clear the whole text----------#
            def clearAll(self):
                self.output = False
                self.current = "0"
                self.display(0)    # Setting the Text to value 0
                self.ValueInput = True
                self.result = 0

        # Assigning a variable to store all objects of the Calculator() class
        ValueAdded = Calculator()

        # ---------Creating a Text entry using the Entry wigdet-----------#
        Text = Entry(Leftframe0, font=('arial', 20, 'italic', 'bold'), bg="#d9d9d9", bd=7, width=27, justify=RIGHT)
        Text.grid(row=0, column=0, columnspan=4, pady=1)
        Text.insert(0, "0")  # Setting the initial value to 0

        numbers = "789456123"  # Creating a variable that is storing numbers to be entered in the calculator

        j = 0

        buttonsNum = []

        # ---------------------------Appending the numbers in the calculator in Leftframe1-----------------------------#
        for i in range(2, 5):  # Appending the numbers in rows in range(2, 5)
            for n in range(3):  # Appendding numbers in columns in range(3)
                # -----------------------------------------Creating numeric Buttons------------------------------------#
                buttonsNum.append(Button(Leftframe1, width=4, height=2, font=('arial', 15, 'bold'), bd=3, text=numbers[j]))
                buttonsNum[j].grid(row=i, column=n, pady=1)
                buttonsNum[j]["command"] = lambda x=numbers[j]: ValueAdded.input(x)  # Creating a command for the numeric buttons
                j += 1
        # -------------------------------------------------------------------------------------------------------------#

        # -------------------------------Creating Mathematical operations buttons----------------------------#

        # ----------------Creating the clear button in Leftframe1 to allow backspacing------------------------#
        Clear_Button = Button(Leftframe1, text='\u232B', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                              bg="#d9d9d9", command=ValueAdded.backspace)  # The command backspace command is called via the ValueAdded variable
        Clear_Button.grid(row=1, column=0, pady=1)

        # ---------Creating the clear everything button in Leftframe1 to allow clearing the whole entry text-----------#
        ClearAll_Button = Button(Leftframe1, text=chr(67) + chr(69), width=4, height=2, font=('arial', 15, 'bold'),
                                 bd=3, bg="#d9d9d9", command=ValueAdded.clearAll)
        ClearAll_Button.grid(row=1, column=1, pady=1)

        # Creating the square root button in Leftframe1 to allow calculating the square root of a number
        # via the command function
        SquareRoot_Button = Button(Leftframe1, text='√', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                   bg="#d9d9d9", command=lambda: ValueAdded.input("sqrt("))
        SquareRoot_Button.grid(row=1, column=2, pady=1)

        # -----Creating the addition button in Leftframe1 to allow calculating sum of numbers
        # via the command function------#
        Add_Button = Button(Leftframe1, text='+', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("+"))
        Add_Button.grid(row=1, column=3, pady=1)

        # -----Creating the subtraction button in Leftframe1 to allow calculating subtraction of numbers
        # via the command function------#
        Subtract_Button = Button(Leftframe1, text='-', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                 bg="#d9d9d9", command=lambda: ValueAdded.input("-"))
        Subtract_Button.grid(row=2, column=3, pady=1)

        # -----Creating the multiply button in Leftframe1 to allow calculating multplication of numbers
        # via the command function------#
        Multiply_Button = Button(Leftframe1, text='*', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                 bg="#d9d9d9", command=lambda: ValueAdded.input("*"))
        Multiply_Button.grid(row=3, column=3, pady=1)

        # -----Creating the division button in Leftframe1 to allow calculating division of numbers
        # via the command function------#
        Division_Button = Button(Leftframe1, text='÷', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                 bg="#d9d9d9", command=lambda: ValueAdded.input("/"))
        Division_Button.grid(row=4, column=3, pady=1)

        # ---Creating the equal to button in Leftframe1 to allow calculating final result of the mathematical operations
        # via the command function------#
        Equal_Button = Button(Leftframe1, text='=', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                              command=ValueAdded.equal)
        Equal_Button.grid(row=5, column=3, pady=1)

        # -----Creating the zero button in Leftframe1 to allow displaying the value 0 sum
        # via the command function------#
        Zero_Button = Button(Leftframe1, text='0', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                             command=lambda: ValueAdded.input('0'))
        Zero_Button.grid(row=5, column=0, pady=1)

        # -----Creating the decimal point button in Leftframe1 to allow displaying the decimal point(.)
        # via the command function------#
        Decimal_Button = Button(Leftframe1, text='.', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                                command=lambda: ValueAdded.input("."))
        Decimal_Button.grid(row=5, column=1, pady=1)

        # -----Creating the negative integer button in Leftframe1 to allow displaying a negative number
        # via the command function------#
        AddSub_Button = Button(Leftframe1, text=chr(177), width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                               bg="#d9d9d9",command=lambda: ValueAdded.input("-"))
        AddSub_Button.grid(row=5, column=2, pady=1)

        # -----Creating the pi button in Leftframe1 to allow the pi value to be executed in calculations
        # via the command function------#
        PI_Button = Button(Leftframe1, text='𝜋', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                           command=lambda: ValueAdded.input("PI"))
        PI_Button.grid(row=1, column=4, pady=1)

        # -----Creating the 2pi button in Leftframe1 to allow the 2pi value to be executed in calculations
        # via the command function------#
        PI2_Button = Button(Leftframe1, text='2𝜋', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("2*PI"))
        PI2_Button.grid(row=2, column=4, pady=1)

        # -----Creating x to the power of 2 button in Leftframe1 to allow squaring numbers
        # via the command function------#
        Xsquare_Button = Button(Leftframe1, text='x\u00b2', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                bg="#d9d9d9", command=lambda: ValueAdded.input("**2"))
        Xsquare_Button.grid(row=3, column=4, pady=1)

        # -----Creating x to the power of 3 button in Leftframe1 to allow  cubing numbers
        # via the command function------#
        Xcube_Button = Button(Leftframe1, text='X\u00b3', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                              bg="#d9d9d9", command=lambda: ValueAdded.input("**3"))
        Xcube_Button.grid(row=4, column=4, pady=1)

        # -----Creating the modulo button in Leftframe1 to allow calculating modulo of numbers
        # via the command function------#
        Modulo_Button = Button(Leftframe1, text='Mod', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                               bg="#d9d9d9", command=lambda: ValueAdded.input("%"))
        Modulo_Button.grid(row=5, column=4, pady=1)

        # -----Creating sin button in Leftframe1 to allow calculating the sin of a number
        # via the command function------#
        sin_Button = Button(Leftframe1, text='sin', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("sin("))
        sin_Button.grid(row=1, column=5, pady=1)

        # -----Creating cos button in Leftframe1 to allow calculating the cos of a number
        # via the command function------#
        cos_Button = Button(Leftframe1, text='cos', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("cos("))
        cos_Button.grid(row=2, column=5, pady=1)

        # -----Creating tan button in Leftframe1 to allow calculating the tan of a number
        # via the command function------#
        tan_Button = Button(Leftframe1, text='tan', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("tan("))
        tan_Button.grid(row=3, column=5, pady=1)

        # -----Creating exponent button in Leftframe1 to allow calculating the exponent of a number
        # via the command function------#
        Exponent_Button = Button(Leftframe1, text='e', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                 bg="#d9d9d9", command=lambda: ValueAdded.input("exp("))
        Exponent_Button.grid(row=4, column=5, pady=1)

        # -----Creating a button in Leftframe1 to a number to be multiplied by 10 power another number
        # via the command function------#
        ln_Button = Button(Leftframe1, text='x10\u2071', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                           bg="#d9d9d9", command=lambda: ValueAdded.input("*10**("))
        ln_Button.grid(row=5, column=5, pady=1)

        # -----Creating x inverse button in Leftframe1 to allow calculating 1 divide by a number
        # via the command function------#
        xIn_Button = Button(Leftframe1, text='1/x', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                            command=lambda: ValueAdded.input("1/("))
        xIn_Button.grid(row=2, column=6, pady=1)

        # -----Creating factorial button in Leftframe1 to allow calculating the factorial of a number
        # via the command function------#
        xFac_Button = Button(Leftframe1, text='x!', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                             command=lambda: ValueAdded.input("!"))
        xFac_Button.grid(row=3, column=6, pady=1)

        # -----Creating log button in Leftframe1 to allow calculating the log of a number
        # via the command function------#
        lg_Button = Button(Leftframe1, text='log', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                           command=lambda: ValueAdded.input("log("))
        lg_Button.grid(row=5, column=6, pady=1)

        # -----Creating power button in Leftframe1 to allow calculating a number to the power of another number
        # via the command function------#
        power_Button = Button(Leftframe1, text='^', width=4, height=2, font=('arial', 15, 'bold'), bd=3, bg="#d9d9d9",
                              command=lambda: ValueAdded.input("**"))
        power_Button.grid(row=4, column=6, pady=1)

        # -----Creating brackets button in Leftframe1 to allow displaying brackets----------#
        bracket_Button = Button(Leftframe1, text='()', width=4, height=2, font=('arial', 15, 'bold'), bd=3,
                                bg="#d9d9d9", command=lambda: ValueAdded.input("()"))
        bracket_Button.grid(row=1, column=6, pady=1)

        # ***************************Menu*****************************#
        def iExit():
            iExit = tkinter.messagebox.askyesno("Scientific Calculator", "Are you sure to exit?")
            if iExit > 0:       # if the user clients on yes, then the calculator program will be terminated
                window.destroy()
                return

        # -----------------Creating a menu in the calculator frame-----------------------------#
        menu = Menu(calculator)

        menuExit = Menu(menu, tearoff=0)  # tearoff = 0 means that choices will be added starting at position 0
        menuTime = Menu(menu, tearoff=0)
        # Displaying local time on the menu
        menu.add_cascade(label=time.asctime(time.localtime(time.time())), menu=menuTime)
        menu.add_cascade(label="Exit Calculator?", menu=menuExit)
        # if the user clicks on exit, will be asked if he/she really wants to execute since a message box will appear
        menuExit.add_command(label="Exit", command=iExit)

        window.config(menu=menu)
        window.mainloop()
        return


# ------------------------Creating another frame in the first window-------------------------#
LabelFrame = Frame(window1_Frame, bd=5, width=300, height=300, relief=RIDGE, bg="#8c8c8c")
LabelFrame.grid(row=10, column=5, columnspan=6, rowspan=2)

# --------------Creating the load button for the calculator in the Labelframe----------------#
# after the execution of the load button, the bar function will be called in order to display the calculator program
LoadButton = Button(LabelFrame, text="Load Calculator Program", command=bar)
LoadButton.grid(row=6, column=0)
window1.mainloop()




