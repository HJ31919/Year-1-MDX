import socket
import csv
import os
import input_variable as inp
HOST = '127.0.0.1'
PORT = 65432
# step 1 Create a server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# step 2  Bind
server_socket.bind((HOST, PORT))
# step 3 Listen
server_socket.listen(1)
print('Waiting for connection:You can now use the machine')
# step 4 Accept
socket_client, (host, port) = server_socket.accept()
print(f'Received connection from {host} ({port})\n')
print(f'Connection Established., Connected from: {host}')
# step 5 Received data from server
received_data = socket_client.recv(1024)
received_data= received_data.decode()
print(f': The client said: {received_data} ')
# Sending data to the client
server_message = 'Welcome to our Vending Machine\n Please select your drink:)'
socket_client.send(server_message.encode())
# step 6 Close the connection
socket_client.close()

'''--------------------------------Intermediate Variable file name which can be edited as needed--------------------------------- '''

# Assign current date to a variable
today_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')

file_name = 'vm_data.csv'
temp_file = 'temp.csv'
product_price = 25

# selection button image filename
coke = 'coke.png'
sprite = 'sprite.png'
orangina = 'orangina.png'
water1 = 'water1.png'

# Function to return path of filename
# update below path based on the image file and csv file location
def database_file(filename):
    return os.path.join('C:', os.sep, 'Users', 'User', 'Documents', 'VendingMachine', 'icon', filename)

def remove_file():
    os.remove(database_file(temp_file))



    '''--------------------------------------- Data load to backend file----------------------------------------------- '''

# Function to evaluate the selection and perform data entry to backend file
def data_entry(item_number):
     if item_number == '1':
         product_name = "coca"
     elif item_number == '2':
         product_name = "7up"
     elif item_number == '3':
         product_name = "orangina"
     else:
         product_name = "water1"
     if os.path.exists(inp.database_file(inp.file_name)):
        with open(inp.database_file(inp.file_name), 'a') as csv_file:
            csv_writer = csv.writer(csv_file, lineterminator='\n')
            csv_writer.writerow([item_number, product_name, inp.product_price, inp.today_date])
     else:
         with open(inp.database_file(inp.file_name), 'w') as csv_file:
              csv_writer = csv.writer(csv_file, lineterminator='\n')
              csv_writer.writerow(['Product_ID', 'Product_Name', 'Product_Price', 'Sales_Date'])
              csv_writer.writerow([item_number, product_name, inp.product_price, inp.today_date])
