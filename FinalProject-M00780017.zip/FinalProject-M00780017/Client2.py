
'''Libraries imported '''
import tkinter as tk
from gtts import gTTS
import csv
import os
import datetime
import input_variable as inp
import report as rpt
import data_load as dl
import pandas as pd
import matplotlib.pyplot as plt
import socket

''''''''' ---------------------------------------VENDING MACHINE------------------------------------------'''''''''''

HOST = '127.0.0.1'
PORT = 65432
# step 1 Create a server socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# step 2 Connect
client_socket.connect((HOST, PORT))
# step 3 Sending data to the server
message = 'Hello from Client'
client_socket.send(message.encode())
# step 4 Receiving data back from the server
received_message = client_socket.recv(1024)
server_message = received_message.decode()
print(f': Message from Server: {server_message} ')
# step 5 Close the connection
client_socket.close()

''''-----------------------------------display actual time and date-------------------------------------'''''
today_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')


# --------------------------------Popup main window-----------------------------------------------
main_window = tk.Tk()
main_window.title("Vending Machine") #setting the title
main_window.configure(background='#979797') #setting a background colour
main_window.iconbitmap(r'favicon.ico') #changing the window icon
main_window.geometry("413x478+430+100") #calculation of geometry

welcome_lbl = tk.Label(main_window,
                       text="Welcome to our \n Vending Machine \n Program \n Date : {}".format(today_date),
                       background='#979797',
                       font="Verdana 12 italic")
welcome_lbl.pack()

# -------------------Adding a welcome text which will be converted into an audio file----------------#
        # The text that you want to convert to audio
mytext = 'Welcome to our vending machine! Please select your drink!'

        # Language in which you want to convert
language = 'en'

        # Text and language are passed to the engine,
        # We've set slow=False in this case.
        # This instructs the module to transform the audio at a high speed.
myobj = gTTS(text=mytext, lang=language, slow=False)

        # Save the converted audio as a welcome.mp3 file.
myobj.save("welcome.mp3")

        # Playing the converted file
os.system("start welcome.mp3")

# ------------------------------------selection button image for soft drinks----------------------------------------
coca = 'coca.png'
sevenup = '7up.png'
orangina = 'orangina.png'
water1 = 'water1.png'


# ------------------------------------Selection Image location------------------------------------------------------
coca = tk.PhotoImage(file=inp.database_file(inp.coca)).subsample(3, 3)
sevenup = tk.PhotoImage(file=inp.database_file(inp.sevenup)).subsample(2, 2)
orangina = tk.PhotoImage(file=inp.database_file(inp.orangina)).subsample(2, 2)
water1 = tk.PhotoImage(file=inp.database_file(inp.water1)).subsample(2, 2)

# selection frame
selection_frame = tk.Frame(main_window)
selection_frame.pack(side=tk.TOP)

# message frame
message_frame = tk.Frame(main_window)
message_frame.pack(side=tk.LEFT)

# payment button frame
payment_frame = tk.Frame(main_window)
payment_frame.pack(side=tk.BOTTOM)

# report button frame
report_frame = tk.Frame(main_window)
report_frame.pack(side=tk.RIGHT)

# -------------------------------------------selection button---------------------------------------------
s1_button = tk.Button(selection_frame, text="coca", image=coca, command=lambda: payment(1)).grid(row=0, column=0)
s2_button = tk.Button(selection_frame, text="7up", image=sevenup, command=lambda: payment(2)).grid(row=0, column=1)
s3_button = tk.Button(selection_frame, text="orangina", image=orangina, command=lambda: payment(3)).grid(row=1, column=0)
s4_button = tk.Button(selection_frame, text="water1", image=water1, command=lambda: payment(4)).grid(row=1, column=1)

# Popup window for Statement Selection
def popup():
    popup_window = tk.Tk()
    popup_window.title("Statement")
    popup_window.configure(background='#979797')
    popup_window.geometry("250x200")
    popup_window.iconbitmap(r'favicon.ico')
    label = tk.Label(popup_window, text="Details", background='#247afd')
    label.pack()
    daily_sales_button = tk.Button(popup_window, text="Daily Sales details", background='#00ffff', command=lambda: rpt.daily_sales() if os.path.exists(inp.database_file(inp.file_name)) else msg()).pack()
    product_sales_button = tk.Button(popup_window, text="Product Sales details", background='#00ffff', command=lambda: rpt.product_sales() if os.path.exists(inp.database_file(inp.file_name)) else msg()).pack()
    popup_window.mainloop()


# Error message when no data is missing or has been created
def msg():
    msg_window = tk.Tk()
    msg_window.title("Error Message")
    msg_window.geometry("200x100")
    label = tk.Label(msg_window, text="Error: No purchase made")
    label.pack()
    msg_window.mainloop()


# -----------------Selection button response message and store selection item in temp file----------------------------
def payment(value):
    payment_label = tk.Label(message_frame, text="\t\tPayment Due : Rs {} \t\t".format(inp.product_price), background='#00ffff').grid(row=0, column=0)
    with open(inp.database_file(inp.temp_file), 'w') as tp:
        csv_writer = csv.writer(tp)
        csv_writer.writerow([value])

# Cancel button to reset the message contain
def clear_payment():
    if os.path.exists(inp.database_file(inp.temp_file)):
        payment_label = tk.Label(message_frame, text="\tSelect your product\t\t", background='#00ffff').grid(row=0, column=0)
        inp.remove_file()
    else:
        payment_label = tk.Label(message_frame, text="\tSelect your product\t\t", background='#00ffff').grid(row=0, column=0)

# Payment button function with response message and dataload to the csv file
def payment_complete():
    if os.path.exists(inp.database_file(inp.temp_file)):
        payment_label = tk.Label(message_frame, text="\tThank you for your Payment\t\t", background='#000fff000').grid(row=0, column=0)
        with open(inp.database_file(inp.temp_file), 'r') as sel:
            pass_val = sel.readline().rstrip()
            dl.data_entry(pass_val)
        inp.remove_file()
    else:
        payment_label = tk.Label(message_frame, text="\tSelect your product\t\t", background='#00ffff').grid(row=0, column=0)


# payment button
p1_button = tk.Button(payment_frame, text="Payment", command=payment_complete, background='#9cbb04').grid(row=0, column=0)
p2_button = tk.Button(payment_frame, text="Cancel", command=clear_payment, background='#9cbb04').grid(row=0, column=1)

# report button
r1_button = tk.Button(report_frame, text="statement", command=popup, background='#247afd').grid(row=0, column=0)

''' -------------------------------------Product Bar Chart Reports-----------------------------------------'''

# Generation of  Daily Sales Bar Chart
def daily_sales():
    df = pd.read_csv(inp.database_file(inp.file_name))
    daily_sales = df.groupby(['Sales_Date']).Product_Price.sum().reset_index()
    daily_sales.plot(kind='bar', x='Sales_Date', y='Product_Price', background='#247afd')
    plt.xlabel("Date", labelpad=11)
    plt.ylabel("Sales Amount", labelpad=11)
    plt.title("Daily Sales Amount Details", y=1.02)
    plt.gcf().subplots_adjust(bottom=0.2)
    plt.legend().set_visible(False)
    plt.show()

# Generation of Product Sales Count Bar Chart
def product_sales():
    df = pd.read_csv(inp.database_file(inp.file_name))
    product_sales = df.groupby(['Product_Name']).Product_Price.count().reset_index()
    product_sales.plot(kind='bar', x='Product_Name', y='Product_Price')
    plt.xlabel("Product Name", labelpad=11)
    plt.ylabel("Product Count", labelpad=11)
    plt.title("Product Sales Count Details", y=1.02)
    plt.legend().set_visible(False)
    plt.show()

# ----------------------------------Function to return path of filename--------------------------------------------
def database_file(filename):
    return os.path.join('C:', os.sep, 'Users', 'User', 'Documents', 'VendingMachine', 'icon', filename)

def remove_file():
    os.remove(database_file(temp_file))

main_window.mainloop()