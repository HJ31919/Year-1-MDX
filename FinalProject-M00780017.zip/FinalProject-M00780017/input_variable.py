import os
import datetime

'''----------------------------------- Variable file name which can be edited as needed------------------------------------- '''

# Assign current date to a variable
today_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')

file_name = 'vm_data.csv'
temp_file = 'temp.csv'
product_price = 25

# selection button image filename
coca = 'coca.png'
sevenup = '7up.png'
orangina= 'orangina.png'
water1 = 'water1.png'

# Function to return path of filename
# update below path based on the image file and csv file location
def database_file(filename):
    return os.path.join('C:', os.sep, 'Users', 'User', 'Documents', 'VendingMachine', 'icon', filename)

def remove_file():
    os.remove(database_file(temp_file))



